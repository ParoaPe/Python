# Importing necessary packages
import pyautogui as pg 
import time

# Timer for sending messages
time.sleep(10)

# Open the folder with variables
txt = open("animals.txt", "r")

# Text
a = "Your enemy is"

# Loop for write all of animals names and Enter action
for i in txt:
    pg.write(a+" "+i)
    pg.press("Enter")
